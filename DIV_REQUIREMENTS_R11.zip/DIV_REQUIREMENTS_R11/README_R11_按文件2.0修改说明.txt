R11：以《A仿真程序任务与交付说明》参数版本2.0和《A_10月16日任务与交付清单》为准。

关键修复：
1. 判别区间保持文件2.0：DIV0~DIV8 的 VB/VA 区间不改。
2. ADC沿用已跑通的多通道Proteus例程：ADC1扫描2个Rank、Discontinuous=ENABLE、NbrOfDiscConversion=1。
3. 修复VB/VA顺序：当前Proteus实测出现第一次ADC值≈VA、第二次≈VB，导致正常工况被记录成VB≈909、VA≈455。
   R11先取得两次真实ADC值，再利用DIV拓扑恒有VA>=VB的关系归一化：较小值=VB、较大值=VA。
   这使文件2.0的全部九种DIV工况都对应正确节点：
   DIV0 正常      VB 422~488,  VA 889~928
   DIV1 R1断路    VB 0附近,    VA 985~1015
   DIV2 R2断路    VB 985~1015, VA 985~1015
   DIV3 R1短路    VB 811~855,  VA 811~855
   DIV4 R2短路    VB 0附近,    VA 811~855
   DIV5 R1=5K     VB 555~621,  VA 862~903
   DIV6 R1=20K    VB 284~342,  VA 919~956
   DIV7 R2=5K     VB 267~322,  VA 862~903
   DIV8 R2=20K    VB 591~659,  VA 919~956
4. OLED不再只显示 NORMAL/FAULT，而显示具体工况：
   DIV0 NORMAL / DIV1 R1 OPEN / DIV2 R2 OPEN / DIV3 R1 SHORT / DIV4 R2 SHORT /
   DIV5 R1=5K / DIV6 R1=20K / DIV7 R2=5K / DIV8 R2=20K。
   当前OLED中文字库仅有少量无关汉字，故先用ASCII等价名称；若必须中文，需要另加“正常/断路/短路/为”等字模。
5. OLED显示的VB/VA是本轮1V检测阶段真实ADC值；不得用3V运行阶段电压与文件中的1V标称值比较。
6. 每轮测量结果无条件交给显示模块，修复STOP后RETEST串口已更新但OLED仍停在旧画面的缓存问题。
7. 正常DIV0：检测结束 TEST_POWER=OFF，RUN_POWER=ON；任何已知故障/UNKNOWN/ADC错误：两路均OFF。

建议验收：
正常：R1=R2=10K；SW6、SW4闭合；SW5、SW2断开。预期VB约455mV，VA约909mV，DIV0，R:ON。
R1断路：从正常只断SW6。预期VB约0mV，VA约1000mV，DIV1，R:OFF。
R1短路：正常基础上闭合SW5旁路R1。预期VB≈VA≈833mV，DIV3，R:OFF。
R1=20K：恢复正常，只把R1改20K。预期VB约312mV，VA约938mV，DIV6，R:OFF。

注意：修改CubeMX后必须保证 PA0=ADC1_IN0、PA1=ADC1_IN1、PA4=GPIO_EXTI4(PULLUP)、PA5=GPIO_EXTI5(PULLUP)，并启用EXTI4和EXTI9_5 NVIC；否则Generate Code会覆盖手工配置。
