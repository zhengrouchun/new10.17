/* 解决ADC采样与判别流程集中在main.c：测量模块实现。 */
#include "main.h"
#include "adc.h"
#include "usart.h"
#include "div_config.h"
#include "div_app_types.h"
#include "div_diagnosis.h"
#include "div_power.h"
#include "div_display.h"
#include "div_measurement.h"
#include <stdio.h>
#include <string.h>
static const char *ReadAdcPair(uint32_t *vb_raw, uint32_t *va_raw, uint32_t *conversions)
{
    /*
     * 按已跑通的“ADC多通道采集”例程工作：
     * ADC1 扫描序列共有两个 Rank，Discontinuous=ENABLE，NbrOfDiscConversion=1。
     * 第一次软件启动得到 Rank1(PA0/IN0/VB)，第二次软件启动得到 Rank2(PA1/IN1/VA)。
     * 不再在每次采样前动态 HAL_ADC_ConfigChannel，避免 Proteus 下出现 Poll 超时。
     */
    if (DivPower_StopIsActive())
    {
        return "STOP_REQUESTED";
    }

    if (HAL_ADC_Start(&hadc1) != HAL_OK)
    {
        return "ADC_START_VB_FAILED";
    }
    if (HAL_ADC_PollForConversion(&hadc1, ADC_TIMEOUT_MILLISECONDS) != HAL_OK)
    {
        HAL_ADC_Stop(&hadc1);
        return "ADC_POLL_VB_FAILED";
    }
    *vb_raw = HAL_ADC_GetValue(&hadc1);
    ++(*conversions);

    if (DivPower_StopIsActive())
    {
        HAL_ADC_Stop(&hadc1);
        return "STOP_REQUESTED";
    }

    if (HAL_ADC_Start(&hadc1) != HAL_OK)
    {
        HAL_ADC_Stop(&hadc1);
        return "ADC_START_VA_FAILED";
    }
    if (HAL_ADC_PollForConversion(&hadc1, ADC_TIMEOUT_MILLISECONDS) != HAL_OK)
    {
        HAL_ADC_Stop(&hadc1);
        return "ADC_POLL_VA_FAILED";
    }
    *va_raw = HAL_ADC_GetValue(&hadc1);
    ++(*conversions);

    if (HAL_ADC_Stop(&hadc1) != HAL_OK)
    {
        return "ADC_STOP_FAILED";
    }

    if (*vb_raw > DIV_ADC_MAX_CODE || *va_raw > DIV_ADC_MAX_CODE)
    {
        return "ADC_RANGE_FAILED";
    }

    return "OK";
}

static void SendReport(const DivMeasurement *result) /* 只发送已经保存的检测结果，不再进行 ADC 转换。 */
{
    char line[REPORT_BUFFER_SIZE]; /* 保存完整的一行串口报告。 */
    char state_text[16] = "UNKNOWN"; /* 未确认唯一匹配前使用未知状态。 */
    char vb_raw_text[12] = "NA"; /* 未取得有效 VB 原码时不发送伪造的零。 */
    char va_raw_text[12] = "NA"; /* 未取得有效 VA 原码时显示未读。 */
    char vb_mv_text[12] = "NA"; /* VB 未读时没有可用的毫伏值。 */
    char va_mv_text[12] = "NA"; /* VA 未读时没有可用的毫伏值。 */
    const char *kind = "UNKNOWN"; /* 将正常、已知故障、未知分开显示。 */
    int written; /* 保存 snprintf 实际需要的字符数。 */
    /* R10修复：无条件把最新测量结果交给显示模块。
     * 旧代码在这里使用 #if OLED_DISPLAY_ENABLE，但本文件没有包含 oled_display.h，
     * 因此该宏在此编译单元中可能未定义，被预处理器当作 0，导致这行被整个编译掉。
     * 结果就是：串口能得到新的 DIV 结果，但 OLED 的 last_measurement/has_measurement/display_dirty 永远不更新。
     */
    DivDisplay_SetMeasurement(result);
    if (result->state >= 0) /* 只有唯一匹配才输出 DIV 编号。 */
    {
        snprintf(state_text, sizeof(state_text), "DIV%d", result->state); /* 将内部编号转换为 DIV0 至 DIV8。 */
        kind = result->state == DIV_NORMAL_CASE ? "NORMAL" : "FAULT"; /* 正常编号使用具名常量表达。 */
    }
    if (result->vb_valid) /* 只有有效 VB 采样才能进入报告。 */
    {
        snprintf(vb_raw_text, sizeof(vb_raw_text), "%lu", (unsigned long)result->vb_raw); /* 格式化真实 VB 原码。 */
        snprintf(vb_mv_text, sizeof(vb_mv_text), "%lu", (unsigned long)result->vb_mv); /* 格式化 VB 换算值。 */
    }
    if (result->va_valid) /* 独立判断 VA，避免沿用上一轮数据。 */
    {
        snprintf(va_raw_text, sizeof(va_raw_text), "%lu", (unsigned long)result->va_raw); /* 格式化真实 VA 原码。 */
        snprintf(va_mv_text, sizeof(va_mv_text), "%lu", (unsigned long)result->va_mv); /* 格式化 VA 换算值。 */
    }
#if DIV_REFERENCE_SERIAL_MODE /* 字段名称、顺序及换行与参考工程和截图保持一致。 */
    written = snprintf(line, sizeof(line), /* 将本轮实际测量值组织成一行。 */
        "STATE=%s KIND=%s VB_RAW=%s VB_MV=%s VA_RAW=%s VA_MV=%s " /* 状态、类型、VB和VA原码及毫伏值。 */
        "FEATURE_READS=%lu ADC_CONVERSIONS=%lu ELAPSED_MS=%lu " /* 有效节点数、成功转换数、检测耗时。 */
        "RUN_POWER=NOT_IMPLEMENTED ERROR=%s\r\n", /* 此模式只使能1V测试，不实现3V运行供电；格式与图二一致。 */
        state_text, kind, vb_raw_text, vb_mv_text, va_raw_text, va_mv_text, /* 依次填入前六个文本字段。 */
        (unsigned long)result->feature_reads, (unsigned long)result->adc_conversions, /* 计数来自当前这轮采样。 */
        (unsigned long)result->elapsed_ms, result->error); /* 耗时和错误来自当前这轮检测。 */
#else /* 保留原受控电源模式的真实控制脚报告。 */
    written = snprintf(line, sizeof(line), /* 按固定字段名组成便于保存与核对的串口记录。 */
        "STATE=%s KIND=%s VB_RAW=%s VB_MV=%s VA_RAW=%s VA_MV=%s " /* 先输出状态和两点原码、电压。 */
        "FEATURE_READS=%lu ADC_CONVERSIONS=%lu ELAPSED_MS=%lu " /* 分别输出节点数、转换数和检测耗时。 */
        "RUN_POWER=%s TEST_POWER=%s POWER_SOURCE=GPIO_LEVEL ERROR=%s\r\n", /* GPIO 电平是控制证据，不能冒充独立电源测量。 */
        state_text, kind, vb_raw_text, vb_mv_text, va_raw_text, va_mv_text, /* 对应前六个文本字段。 */
        (unsigned long)result->feature_reads, (unsigned long)result->adc_conversions, /* 使用本轮实际累加的计数。 */
        (unsigned long)result->elapsed_ms, /* 输出包含测试准备和供电切换的检测耗时。 */
        HAL_GPIO_ReadPin(GPIOB, RUN_POWER_PIN) == GPIO_PIN_SET ? "ON" : "OFF", /* 读取 PB13 的实际逻辑电平快照。 */
        HAL_GPIO_ReadPin(GPIOB, TEST_POWER_PIN) == GPIO_PIN_SET ? "ON" : "OFF", /* 读取 PB12 的实际逻辑电平快照。 */
        result->error); /* 输出本轮的 ADC 错误或停止原因。 */
#endif /* 结束串口报告格式选择。 */
    if (written < 0 || written >= (int)sizeof(line)) /* 检查格式化失败和缓冲区不足。 */
    {
        Error_Handler(); /* 不发送截断或损坏的记录。 */
    }
    if (HAL_UART_Transmit(&huart1, (uint8_t *)line, (uint16_t)written, UART_TIMEOUT_MILLISECONDS) != HAL_OK) /* 由 PA9 发往终端 RXD。 */
    {
        Error_Handler(); /* 串口发送失败时停止，避免伪称已交付数据。 */
    }
}

void DivMeasurement_Run(void) /* 每轮重新采集VB、VA，再换算、判别并输出一条报告。 */
{
    DivMeasurement result = {0}; /* 清空这一轮记录；两个有效标志均为假。 */
    uint32_t started_ms = HAL_GetTick(); /* 先记录准备开始时刻；截图模式在电源稳定后重置采样计时。 */
    result.state = DIV_UNKNOWN; /* 在读完两点并成功判别之前维持未知。 */
    result.error = "STOP_REQUESTED"; /* 建立测试状态失败时报告停止，不能伪造 ADC 数据。 */
    if (!DivPower_Select(TEST_POWER_PIN) || !DivPower_WaitWithoutStop(TEST_POWER_OBSERVATION_MILLISECONDS)) /* 关闭运行、互锁等待、打开测试并保持1.5秒供观察。 */
    {
        DivPower_AllOff(); /* 建立测试状态失败时保证双路关闭。 */
        result.elapsed_ms = HAL_GetTick() - started_ms; /* 保存到取消时刻的真实耗时。 */
        SendReport(&result); /* 未采样的电压输出 NA，次数保持零。 */
        return; /* 本次被取消，等待新的复测事件。 */
    }
#if DIV_REFERENCE_SERIAL_MODE /* 串口沿用参考工程的采样计时口径，不计入建立1V测试条件的等待。 */
    started_ms = HAL_GetTick(); /* PB12已使能且稳定20ms后，从真正准备采样时开始计时。 */
#endif /* 原受控运行模式仍保留包含电源切换的总耗时。 */
    result.error = ReadAdcPair(&result.vb_raw, &result.va_raw, &result.adc_conversions); /* 按Rank1/Rank2顺序一次读取VB、VA。 */
    if (strcmp(result.error, "OK") == 0)
    {
        result.vb_valid = 1;
        result.va_valid = 1;
        result.vb_mv = DivCodeToMillivolts(result.vb_raw);
        result.va_mv = DivCodeToMillivolts(result.va_raw);
        result.feature_reads = 2;
        result.state = DivClassify((int32_t)result.vb_mv, (int32_t)result.va_mv);
    }
    if (DivPower_StopIsActive()) /* 即使停止发生在 ADC 转换期间，也禁止接受结果并开启运行。 */
    {
        result.state = DIV_UNKNOWN; /* 已取消的检测不作为正常或故障验收结果。 */
        result.error = "STOP_REQUESTED"; /* 报告本轮取消原因。 */
        DivPower_AllOff(); /* 保持停止时的双路关闭。 */
    }
#if !DIV_REFERENCE_SERIAL_MODE /* 截图模式不自动切到3V，避免下一轮采到运行态电压。 */
    else if (strcmp(result.error, "OK") == 0 && result.vb_valid && result.va_valid && result.state == DIV_NORMAL_CASE) /* 两点均成功且唯一匹配正常才进入运行。 */
    {
        if (!DivPower_Select(RUN_POWER_PIN) || DivPower_StopIsActive()) /* 先断开测试电源，再等待 5 ms，最后尝试开启运行。 */
        {
            result.state = DIV_UNKNOWN; /* 切换被停止取消时拒绝正常结果。 */
            result.error = "STOP_REQUESTED"; /* 输出明确的取消原因。 */
            DivPower_AllOff(); /* 保证双路最终关闭。 */
        }
    }
    else /* 已知故障、未知工况或任何 ADC 失败都不允许进入运行。 */
    {
        DivPower_AllOff(); /* 检测完成后连测试电源也关闭，保持等待复测状态。 */
    }
#else /* 连续串口测试模式完成本轮后关闭测试使能，下一轮重新建立1V条件。 */
    DivPower_AllOff(); /* 将PB12和PB13拉低；图中手动SW1/SW7仍需用户实际操作。 */
#endif /* 结束原受控电源模式的运行切换。 */
    result.elapsed_ms = HAL_GetTick() - started_ms; /* 记录真实耗时，不计串口发送和500ms等待，不固定为截图中的2ms。 */
    SendReport(&result); /* 发送刚采集到的数据，下一轮会重新读取ADC。 */
#if DIV_REFERENCE_SERIAL_MODE /* 与参考代码一致，ADC错误报告后停止；按键停止仍允许PA4恢复。 */
    if (strcmp(result.error, "OK") != 0 && strcmp(result.error, "STOP_REQUESTED") != 0) /* 区分ADC失败和用户主动停止。 */
    {
        Error_Handler(); /* ADC失败时保留故障现场，复位后重新校准和测量。 */
    }
#endif /* 结束截图模式的ADC故障处理。 */
}

