DIV_REQUIREMENTS_R15 修改说明
==============================

一、严格按任务文件的工况编号，不改判别表
DIV0 正常：VB 422~488mV，VA 889~928mV
DIV1 R1断路：VB -5~5mV，VA 985~1015mV
DIV2 R2断路：VB 985~1015mV，VA 985~1015mV
DIV3 R1短路：VB 811~855mV，VA 811~855mV
DIV4 R2短路：VB -5~5mV，VA 811~855mV
DIV5 R1=5k：VB 555~621mV，VA 862~903mV
DIV6 R1=20k：VB 284~342mV，VA 919~956mV
DIV7 R2=5k：VB 267~322mV，VA 862~903mV
DIV8 R2=20k：VB 591~659mV，VA 919~956mV

注意：任务文件里“R1短路”是DIV3，不是DIV1；DIV1是R1断路。

二、供电严格按文件
DIV0检测结束：TEST=OFF，RUN=ON。
所有故障/UNKNOWN/ADC错误检测结束：TEST=OFF，RUN=OFF。
STOP：TEST=OFF，RUN=OFF。

三、R15主要修复
1. ADC不再按“大小排序”猜VB/VA。
   Rank1=PA0=DIV_VB，第一次转换直接记VB；Rank2=PA1=DIV_VA，第二次直接记VA。
2. 每轮测量前HAL_ADC_Stop并清EOC，避免序列位置/旧标志干扰。
3. 增加TEST_SAMPLE日志，它在1V测试仍然开启时打印，必须拿这行和Proteus电压表对比。
4. OLED不再整体缓存DivMeasurement结构体，改为逐字段保存state/VB/VA/valid/error，避免旧值或字段错位。
5. OLED软件I2C增加边沿延时；清屏改成按页连续写，减少Proteus漏写和启动过慢。
6. 上电先执行首轮检测，再初始化OLED；OLED初始化后直接显示首轮真实结果，不再先显示旧DIV0。
7. 固件标识统一为FW=DIV_REQ_R16。
8. UART统一57600，.ioc与usart.c一致，Proteus Virtual Terminal也设57600/8N1。

四、最重要的判断规则
代码不能知道SW5/SW6/SW4/SW2“你想设成什么”，MCU只能看到PA0/PA1的真实电压。
如果你认为当前是DIV0，但TEST_SAMPLE打印VB=588、VA=886，则这组电压按文件就是DIV5，代码必须判DIV5。
这时要查Proteus网络，不应把DIV0阈值改成588/886。

588/886还能反推：VB/VA≈0.664，若R2=10k，则R1等效约5.1k，说明R1通路在仿真中等效成了约5k（例如存在额外并联路径、元件值/开关状态未真正更新等）。

五、验收开关设置（按任务文件）
DIV0正常：R1=R2=10k；SW6、SW4闭合；SW5、SW2断开。
DIV1 R1断路：从DIV0只断开SW6。
DIV3 R1短路：从DIV0保持SW6/SW4闭合，再闭合SW5（SW5跨接R1）。
DIV4 R2短路：从DIV0保持SW6/SW4闭合，再闭合SW2（SW2把VB直接短到GND）。

六、测试步骤
1. 停止Proteus仿真。
2. 按目标工况设置开关/电阻；如果改了电阻值，停止后修改并重新启动仿真，避免使用旧netlist状态。
3. 启动后确认第一行含FW=DIV_REQ_R16。
4. Proteus Virtual Terminal设57600。
5. 看TEST_SAMPLE：这是1V检测阶段的VB/VA。
6. 再看最终STATE行和OLED，三处必须一致。
7. 检测结束后再看T/R：DIV0应T:OFF R:ON；故障应T:OFF R:OFF。

七、如果仍不一致
A. TEST_SAMPLE正确但STATE错：查div_diagnosis.c（R15的表已按文件写好）。
B. TEST_SAMPLE正确、STATE正确但OLED错：查OLED/I2C；R15已把显示缓存和I2C时序改掉。
C. TEST_SAMPLE本身错：这是采集电路/开关/电阻/网络连接问题，不是判别表问题。
   在TEST_SAMPLE出现前的1V阶段，直接测：
   - DIV0：VB约455mV，VA约909mV
   - DIV1：VB约0mV，VA约1000mV
   - DIV3：VB约833mV，VA约833mV
   - DIV4：VB约0mV，VA约833mV
