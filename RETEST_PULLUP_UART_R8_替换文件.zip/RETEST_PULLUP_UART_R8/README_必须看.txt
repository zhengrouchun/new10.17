R8修复重点：
1) 当前工程实际 gpio.c/.ioc 中 PA4、PA5 都是 NOPULL；Proteus 按键原理图又没有外部上拉，所以按钮松开时输入悬空，日志会出现 PA4=LOW、PA5=LOW、STOP=YES，系统一上电就进入 STOP，RETEST 被拒绝。
2) R8把 PA4/RETEST 和 PA5/STOP 都统一为：GPIO_MODE_IT_FALLING + GPIO_PULLUP。
3) 启用 EXTI4_IRQn（优先级1），STOP EXTI9_5 保持优先级0。
4) Proteus按钮接线保持最简单：PA4--SW8--GND；PA5--STOP--GND。不要外接下拉，不要 LogicState。
5) UART 改为 57600。Labcenter 官方当前 Virtual Terminal 文档标注支持 300~57600；Proteus Virtual Terminal也改为57600、8N1。
6) 重新开启每1秒简短状态日志，便于看到 PA4/PA5 是否刷新。

替换后必须 Rebuild，启动第一条应包含：FW=RETEST_PULLUP_UART_R8 ... BAUD=57600
启动后、两个按钮都松开时，必须看到：PA4=HIGH PA5=HIGH STOP=NO。
若看到 PA4=LOW 或 PA5=LOW，先不要测业务，说明电气输入仍不对。
按 RETEST：应出现 RAW_IRQ/ACCEPT 增加、RETEST_ACCEPTED、DETECTION_START。
按 STOP：应出现 EVENT=STOP，并显示 STOPPED。
